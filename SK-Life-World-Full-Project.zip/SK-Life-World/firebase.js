// Firebase multiplayer setup: paste your own Firebase web config below.
// Never commit private service-account keys or Admin SDK credentials.
export const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
export const firebaseReady = !Object.values(firebaseConfig).some(v => String(v).startsWith("YOUR_"));
