import { firebaseConfig, firebaseReady } from "./firebase.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signInAnonymously } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";
import { getFirestore, doc, setDoc, getDoc, collection, addDoc, query, orderBy, limit, onSnapshot, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";

const $ = id => document.getElementById(id);
const money = n => "₨ " + Math.round(n).toLocaleString("en-PK");
const STORE = "sk-life-world-v1";
const jobs = [
 {name:"دکان پر اسسٹنٹ",min:16,salary:18000,desc:"ابتدائی تجربہ اور کسٹمر سروس۔"},
 {name:"ڈیٹا انٹری آپریٹر",min:18,salary:32000,desc:"کمپیوٹر اور ٹائپنگ کی مہارت۔"},
 {name:"گرافک ڈیزائنر",min:18,salary:55000,desc:"ڈیزائن پورٹ فولیو اور تخلیقی سوچ۔"},
 {name:"ویب ڈیولپر",min:18,salary:85000,desc:"HTML، CSS، JavaScript کی مہارت۔"},
 {name:"سافٹ ویئر انجینئر",min:21,salary:150000,desc:"اعلیٰ تعلیم یا مضبوط عملی مہارت۔"},
 {name:"پروجیکٹ مینیجر",min:25,salary:210000,desc:"تجربہ، ٹیم ورک اور قیادت۔"}
];
const courses = [
 {name:"اسکول کی تعلیم",min:10,cost:0,skill:2,edu:1,desc:"بنیادی مضامین، ہر سال تعلیم میں اضافہ۔"},
 {name:"کمپیوٹر بیسکس",min:12,cost:1500,skill:8,edu:0,desc:"کمپیوٹر اور ڈیجیٹل مہارتیں۔"},
 {name:"انگلش لینگویج",min:12,cost:1000,skill:5,edu:0,desc:"مواصلات اور بہتر مواقع۔"},
 {name:"ویب ڈیولپمنٹ",min:15,cost:5000,skill:15,edu:0,desc:"ویب سائٹس بنانا سیکھیں۔"},
 {name:"یونیورسٹی ڈگری",min:18,cost:12000,skill:10,edu:2,desc:"اعلیٰ تعلیم اور بہتر کیریئر کے مواقع۔"},
 {name:"بزنس مینجمنٹ",min:18,cost:8000,skill:12,edu:1,desc:"کاروبار چلانے کی تربیت۔"}
];
const goods = [
 {name:"سائیکل",price:18000,emoji:"🚲",type:"vehicle",desc:"آسان سفر۔"},
 {name:"استعمال شدہ موٹر سائیکل",price:95000,emoji:"🏍️",type:"vehicle",desc:"روزانہ آمدورفت۔"},
 {name:"چھوٹی استعمال شدہ کار",price:850000,emoji:"🚗",type:"vehicle",desc:"آپ کی پہلی کار۔"},
 {name:"نئی فیملی کار",price:2800000,emoji:"🚙",type:"vehicle",desc:"آرام دہ سفر۔"},
 {name:"چھوٹا فلیٹ",price:4500000,emoji:"🏢",type:"property",desc:"اپنی رہائش۔"},
 {name:"فیملی گھر",price:12000000,emoji:"🏠",type:"property",desc:"بڑا گھر اور زیادہ جگہ۔"},
 {name:"اسمارٹ فون",price:45000,emoji:"📱",type:"item",desc:"رابطے اور کام کے لیے۔"}
];
let state = null, db = null, auth = null, user = null, cloudUnsub = null;
const defaultState = (name,username,city)=>({name,username:username.toLowerCase(),city,age:10,year:1,day:1,balance:5000,income:0,expenses:500,education:0,educationName:"ابتدائی",skills:0,mindset:50,job:null,business:null,assets:[],friends:[],friendRequests:[],messages:[],events:[{text:"آپ نے 10 سال کی عمر میں SK Life World میں اپنا سفر شروع کیا۔",day:1}],lastDailyYear:1});
function saveLocal(){localStorage.setItem(STORE,JSON.stringify(state));if(db&&user)syncPlayer();}
function log(text){state.events.unshift({text,day:state.day,age:state.age});state.events=state.events.slice(0,40);saveLocal();render();}
function toast(msg){$("toast").textContent=msg;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2300);}
function init(){
 $("connection").textContent=firebaseReady?"Firebase configured":"Offline mode";
 try{const saved=localStorage.getItem(STORE);if(saved){state=JSON.parse(saved);showGame();}}catch(e){console.error(e)}
 $("createForm").addEventListener("submit",e=>{e.preventDefault();const name=$("playerName").value.trim(),username=$("playerUsername").value.trim();if(!/^[A-Za-z0-9_]{3,18}$/.test(username)){toast("Username میں 3 سے 18 حروف/نمبر استعمال کریں۔");return;}state=defaultState(name,username,$("playerCity").value);saveLocal();showGame();});
 $("saveBtn").onclick=()=>{if(state){saveLocal();toast("گیم محفوظ ہوگئی۔");}};
 $("nextDay").onclick=()=>advance(1);$("nextWeek").onclick=()=>advance(7);$("nextMonth").onclick=()=>advance(30);
 $("tabs").addEventListener("click",e=>{const b=e.target.closest("[data-tab]");if(!b)return;document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));renderTab(b.dataset.tab);});
 $("editProfile").onclick=()=>toast("پروفائل: "+state.name+" · @"+state.username);
 if(firebaseReady) setupFirebase();
}
function showGame(){$("welcome").classList.add("hidden");$("game").classList.remove("hidden");$("profileName").textContent=state.name;$("profileHandle").textContent="@"+state.username;$("characterName").textContent=state.name;$("cityTitle").textContent=state.city;render();drawWorld();renderTab("life");}
function render(){
 if(!state)return;
 $("age").textContent=state.age+" سال";$("dateLabel").textContent=`سال ${state.year} · دن ${state.day}`;
 $("balance").textContent=money(state.balance);$("income").textContent=money(state.income);$("netWorth").textContent=money(state.balance+state.assets.reduce((a,x)=>a+x.value,0));
 $("educationLabel").textContent=state.educationName;$("skillsLabel").textContent=state.skills;$("mindsetLabel").textContent=state.mindset+"/100";
 $("eventLog").innerHTML=state.events.slice(0,8).map(x=>`<div class="log-item">📌 ${esc(x.text)} <small> · دن ${x.day}</small></div>`).join("");
 drawWorld();
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function advance(days){
 for(let i=0;i<days;i++){state.day++;if(state.day>30){state.day=1;state.year++;state.age=Math.min(100,state.age+1);state.balance-=state.expenses;if(state.job)state.balance+=state.job.salary;if(state.business)state.balance+=state.business.profit;state.mindset=Math.max(0,Math.min(100,state.mindset+(state.balance>=0?1:-2)));if(state.age===18)state.events.unshift({text:"آپ 18 سال کے ہوگئے! اب اعلیٰ تعلیم، نوکری اور کاروبار کے نئے راستے کھل گئے ہیں۔",day:state.day});if(state.age===60)state.events.unshift({text:"آپ کی عمر 60 سال ہوگئی۔ اپنی صحت اور ریٹائرمنٹ کی منصوبہ بندی کریں۔",day:state.day});}}
 saveLocal();render();renderTab(document.querySelector(".tab.active")?.dataset.tab||"life");toast(`${days} دن آگے بڑھ گئے۔`);
}
function card(title,desc,meta,button,action,disabled=false){return `<article class="choice-card"><h3>${title}</h3><p>${desc}</p><div class="meta">${meta}</div><button class="secondary action" data-action="${action}" ${disabled?"disabled":""}>${button}</button></article>`;}
function renderTab(tab){
 const el=$("tabContent");let html="";
 if(tab==="life"){
 const opts=[["پڑھائی جاری رکھیں","تعلیم آپ کے مستقبل کے مواقع بہتر بناتی ہے۔","تعلیم +2، ذہن +1","پڑھائی کریں","study",state.age>18],["ہنر سیکھیں","کوئی نیا کورس مکمل کریں اور مہارت بڑھائیں۔","ہنر +3 · فیس ₨ 1,000","ہنر سیکھیں","skill",state.balance<1000],["رضاکارانہ کام","کمیونٹی میں مدد کریں اور تجربہ حاصل کریں۔","ذہن +3","حصہ لیں","volunteer"]];
 html=`<h2>🌱 آپ کی زندگی کے فیصلے</h2><p>ہر فیصلہ آپ کے مستقبل، مہارت اور مالی حالت پر اثر ڈالتا ہے۔</p><div class="cards">${opts.map(o=>card(...o)).join("")}</div>`;
 } else if(tab==="education"){
 html=`<h2>📚 تعلیم اور سیکھنے کے مواقع</h2><p>اپنی عمر اور بجٹ کے مطابق تعلیم منتخب کریں۔</p><div class="cards">${courses.filter(c=>state.age>=c.min).map(c=>card(c.name,c.desc,`فیس ${money(c.cost)} · مہارت +${c.skill}`,"داخلہ لیں","course:"+c.name,state.balance<c.cost)).join("")}</div>`;
 } else if(tab==="career"){
 html=`<h2>💼 نوکریاں اور کیریئر</h2><p>مطلوبہ عمر اور مہارت پوری کریں۔ نوکری ملنے پر ہر ورچوئل مہینے تنخواہ ملے گی۔</p><div class="cards">${jobs.filter(j=>state.age>=j.min).map(j=>card(j.name,j.desc,`تنخواہ ${money(j.salary)} / ماہ · عمر ${j.min}+`,"اس نوکری کے لیے درخواست","job:"+j.name,state.skills<(j.min>=21?20:5))).join("")}</div>${state.job?`<p class="log-item">موجودہ نوکری: <b>${state.job.name}</b> · تنخواہ ${money(state.job.salary)}</p><button class="ghost" data-action="quitjob">نوکری چھوڑیں</button>`:""}`;
 } else if(tab==="business"){
 html=`<h2>🏢 اپنا کاروبار</h2><p>کاروبار شروع کرنے سے پہلے سرمایہ اور منصوبہ بندی ضروری ہے۔ منافع فرضی گیم اکانومی کے مطابق ہے۔</p><div class="cards">${card("آن لائن اسٹور","چھوٹے پیمانے پر آن لائن چیزیں فروخت کریں۔","سرمایہ ₨ 50,000 · منافع ₨ 8,000 / ماہ","شروع کریں","business:store",state.age<18||state.balance<50000)}${card("کیفے","اپنا چھوٹا کیفے کھولیں۔","سرمایہ ₨ 250,000 · منافع ₨ 30,000 / ماہ","شروع کریں","business:cafe",state.age<18||state.balance<250000)}${card("سافٹ ویئر کمپنی","ٹیکنالوجی کی کمپنی بنائیں۔","سرمایہ ₨ 500,000 · منافع ₨ 65,000 / ماہ","شروع کریں","business:software",state.age<18||state.balance<500000)}</div>${state.business?`<p class="log-item">موجودہ کاروبار: <b>${state.business.name}</b> · ماہانہ منافع ${money(state.business.profit)}</p>`:""}`;
 } else if(tab==="bank"){
 html=`<h2>🏦 بینک اور مالی منصوبہ بندی</h2><div class="cards"><article class="choice-card"><h3>آپ کا اکاؤنٹ</h3><p>موجودہ دستیاب رقم</p><div class="meta">${money(state.balance)}</div></article><article class="choice-card"><h3>ماہانہ اخراجات</h3><p>رہائش، کھانا اور روزمرہ اخراجات کا تخمینہ۔</p><div class="meta">${money(state.expenses)}</div><input id="expenseInput" class="inline-input" type="number" min="0" value="${state.expenses}"><button class="secondary" data-action="expenses">اخراجات اپ ڈیٹ کریں</button></article><article class="choice-card"><h3>اثاثے</h3><p>${state.assets.length?state.assets.map(a=>esc(a.name)).join("، "):"ابھی کوئی اثاثہ نہیں۔"}</p><div class="meta">کل مالیت ${money(state.assets.reduce((s,a)=>s+a.value,0))}</div></article></div><p class="log-item">نوٹ: یہ صرف تعلیمی گیم کی ورچوئل معیشت ہے، حقیقی بینک یا سرمایہ کاری کی سروس نہیں۔</p>`;
 } else if(tab==="market"){
 html=`<h2>🛍 شاپنگ اور پراپرٹی مارکیٹ</h2><div class="cards">${goods.map(g=>card(`${g.emoji} ${g.name}`,g.desc,`قیمت ${money(g.price)}`,"خریدیں","buy:"+g.name,state.balance<g.price||state.age<16)).join("")}</div><h3>آپ کی خریدی ہوئی اشیاء</h3><p>${state.assets.length?state.assets.map(a=>`${a.emoji||"📦"} ${esc(a.name)}`).join(" · "):"ابھی کوئی خریداری نہیں۔"}</p>`;
 } else if(tab==="social"){
 html=`<h2>👥 دوست اور ملاقاتیں</h2><p>Username کے ذریعے دوست تلاش کریں۔ حقیقی Multiplayer کے لیے Firebase config ضروری ہے۔</p><div class="inline-row"><input id="friendName" class="inline-input" placeholder="دوست کا username"><button class="primary" data-action="addfriend">دوست شامل کریں</button></div><h3>آپ کے دوست</h3><div id="friendList">${state.friends.length?state.friends.map(f=>`<div class="log-item">@${esc(f)} <button class="ghost" data-action="chat:${esc(f)}">پیغام</button></div>`).join(""):"ابھی دوست شامل نہیں۔"}</div><div id="chatArea"></div><p class="log-item">دوستوں کے ساتھ چیٹ اور live ملاقات کے لیے آن لائن Firebase database فعال کریں۔</p>`;
 } else if(tab==="ranking"){
 html=`<h2>🏆 عالمی مقابلہ</h2><p>اس ڈیمو میں مقامی کھلاڑی کا اسکور دکھایا جا رہا ہے۔ Firebase فعال ہونے پر عالمی لیڈر بورڈ دستیاب ہوگا۔</p><div class="cards"><article class="choice-card"><h3>آپ کی رینکنگ</h3><div class="meta">مقامی پروفائل</div><strong>${money(state.balance+state.assets.reduce((a,x)=>a+x.value,0))}</strong><p>کل ورچوئل دولت</p></article><article class="choice-card"><h3>Mindset Score</h3><strong>${state.mindset}/100</strong><p>فیصلوں اور مستقل مزاجی پر مبنی گیم اسکور۔</p></article></div>`;
 }
 el.innerHTML=html;
 el.querySelectorAll("[data-action]").forEach(b=>b.addEventListener("click",()=>act(b.dataset.action)));
}
function act(a){
 if(a==="study"){state.education++;state.educationName="اسکول/تعلیم";state.mindset=Math.min(100,state.mindset+1);log("آپ نے پڑھائی جاری رکھی۔");}
 else if(a==="skill"){state.balance-=1000;state.skills+=3;log("آپ نے نیا ہنر سیکھا۔");}
 else if(a==="volunteer"){state.mindset=Math.min(100,state.mindset+3);log("آپ نے کمیونٹی کی خدمت کی۔");}
 else if(a.startsWith("course:")){const c=courses.find(x=>x.name===a.slice(7));if(!c||state.balance<c.cost)return toast("رقم ناکافی ہے۔");state.balance-=c.cost;state.skills+=c.skill;state.education+=c.edu;state.educationName=c.name;log(`آپ نے ${c.name} مکمل کیا۔`);}
 else if(a.startsWith("job:")){const j=jobs.find(x=>x.name===a.slice(4));if(!j)return;if(state.skills<(j.min>=21?20:5))return toast("اس نوکری کے لیے مزید مہارت درکار ہے۔");state.job=j;state.income=j.salary;log(`آپ کو ${j.name} کی نوکری مل گئی۔`);}
 else if(a==="quitjob"){state.job=null;state.income=state.business?.profit||0;log("آپ نے نوکری چھوڑ دی۔");}
 else if(a.startsWith("business:")){const k=a.split(":")[1],b={store:{name:"آن لائن اسٹور",cost:50000,profit:8000},cafe:{name:"کیفے",cost:250000,profit:30000},software:{name:"سافٹ ویئر کمپنی",cost:500000,profit:65000}}[k];if(state.age<18||state.balance<b.cost)return toast("عمر یا سرمایہ کافی نہیں۔");state.balance-=b.cost;state.business=b;state.income=(state.job?.salary||0)+b.profit;log(`آپ نے ${b.name} شروع کیا۔`);}
 else if(a.startsWith("buy:")){const g=goods.find(x=>x.name===a.slice(4));if(!g||state.balance<g.price)return toast("آپ کے پاس کافی رقم نہیں۔");state.balance-=g.price;state.assets.push({name:g.name,value:g.price,emoji:g.emoji,type:g.type});log(`آپ نے ${g.name} خریدی۔`);}
 else if(a==="expenses"){const v=Number($("expenseInput")?.value);if(!Number.isFinite(v)||v<0)return toast("درست رقم لکھیں۔");state.expenses=v;log("ماہانہ اخراجات تبدیل ہوگئے۔");}
 else if(a==="addfriend"){const f=$("friendName")?.value.trim().replace(/^@/,"").toLowerCase();if(!f||f===state.username)return toast("درست دوست username لکھیں۔");if(!state.friends.includes(f)){state.friends.push(f);log(`@${f} کو دوستوں میں شامل کیا (لوکل ڈیمو)۔`);}else toast("یہ دوست پہلے سے شامل ہے۔");}
 else if(a.startsWith("chat:")){const f=a.slice(5);$("chatArea").innerHTML=`<h3>@${esc(f)} کے لیے پیغام</h3><div class="inline-row"><input id="chatText" class="inline-input" placeholder="پیغام لکھیں"><button class="primary" id="sendChat">بھیجیں</button></div><div id="chatMessages"></div>`;$("sendChat").onclick=()=>{const t=$("chatText").value.trim();if(!t)return;state.messages.push({to:f,text:t});saveLocal();$("chatMessages").innerHTML+=`<div class="log-item">${esc(t)}</div>`;$("chatText").value="";};}
 saveLocal();render();renderTab(document.querySelector(".tab.active")?.dataset.tab||"life");
}
function drawWorld(){
 const c=$("world");if(!c||!state)return;const x=c.getContext("2d"),w=c.width,h=c.height;
 x.clearRect(0,0,w,h);x.fillStyle="#9ddce4";x.fillRect(0,0,w,h);
 x.fillStyle="#f8d58b";x.beginPath();x.arc(760,72,35,0,Math.PI*2);x.fill();
 x.fillStyle="#7fc48c";x.fillRect(0,285,w,135);
 // road
 x.fillStyle="#566477";x.fillRect(0,320,w,65);x.fillStyle="#f4e6a0";for(let i=0;i<9;i++)x.fillRect(i*115+20,350,55,5);
 // buildings
 const buildings=[{x:55,y:145,w:150,h:175,c:"#e9a76f"},{x:255,y:105,w:175,h:215,c:"#b5c7dc"},{x:490,y:165,w:135,h:155,c:"#e8d09b"},{x:685,y:130,w:145,h:190,c:"#b0b8d8"}];
 buildings.forEach((b,i)=>{x.fillStyle=b.c;x.fillRect(b.x,b.y,b.w,b.h);x.fillStyle="#526b87";for(let yy=b.y+22;yy<b.y+b.h-15;yy+=42)for(let xx=b.x+18;xx<b.x+b.w-15;xx+=38)x.fillRect(xx,yy,17,22);x.fillStyle="#6c503f";x.fillRect(b.x+b.w/2-13,b.y+b.h-42,26,42);});
 // player
 const px=430,py=278;x.fillStyle="#263d66";x.beginPath();x.arc(px,py-26,14,0,Math.PI*2);x.fill();x.fillStyle="#f2c6a0";x.beginPath();x.arc(px,py-27,10,0,Math.PI*2);x.fill();x.fillStyle="#326db1";x.fillRect(px-13,py-15,26,31);x.fillStyle="#263d66";x.fillRect(px-11,py+15,8,17);x.fillRect(px+3,py+15,8,17);
 x.fillStyle="#17324b";x.font="bold 17px Arial";x.textAlign="center";x.fillText(state.name.slice(0,16),px,py+53);
}
async function setupFirebase(){
 try{
  const app=initializeApp(firebaseConfig);auth=getAuth(app);db=getFirestore(app);
  await signInAnonymously(auth);
  onAuthStateChanged(auth,async u=>{if(!u)return;user=u;$("connection").textContent="Firebase connected";const ref=doc(db,"players",state.username);const snap=await getDoc(ref);if(!snap.exists())await setDoc(ref,{username:state.username,name:state.name,age:state.age,balance:state.balance,netWorth:state.balance,updatedAt:serverTimestamp()});listenFriends();});
 }catch(e){console.warn("Firebase setup:",e);$("connection").textContent="Offline mode";}
}
async function syncPlayer(){if(!db||!user||!state)return;try{await setDoc(doc(db,"players",state.username),{username:state.username,name:state.name,age:state.age,balance:state.balance,netWorth:state.balance+state.assets.reduce((s,a)=>s+a.value,0),updatedAt:serverTimestamp()},{merge:true});}catch(e){console.warn(e);}}
function listenFriends(){if(!db)return;const q=query(collection(db,"players"),orderBy("netWorth","desc"),limit(20));cloudUnsub=onSnapshot(q,s=>{const players=s.docs.map(d=>d.data());if(document.querySelector(".tab.active")?.dataset.tab==="ranking"){$("tabContent").insertAdjacentHTML("beforeend",`<h3>🌐 آن لائن کھلاڑی</h3>${players.map(p=>`<div class="log-item">@${esc(p.username)} · ${esc(p.name)} · ${money(p.netWorth||0)}</div>`).join("")}`);}});}
window.addEventListener("beforeunload",()=>{if(state)saveLocal();});
init();
