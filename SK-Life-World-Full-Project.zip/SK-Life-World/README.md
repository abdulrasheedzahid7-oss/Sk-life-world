# SK Life World

A 2D Urdu life-simulation game starter. The game begins at age 10 and includes education, skills, careers, businesses, banking, shopping, assets, friends, a virtual calendar, and a simple 2D city scene.

## Run locally
Because this project uses JavaScript modules, serve the folder with a local web server (not `file://`).

```bash
python -m http.server 8000
```
Open `http://localhost:8000`.

## GitHub Pages
1. Create a public repository named `sk-life-world`.
2. Upload all project files to the repository root.
3. In GitHub: Settings → Pages → Deploy from a branch → `main` → `/ (root)`.
4. Open the published Pages URL.

## Enable Firebase multiplayer
1. Create a Firebase project at https://console.firebase.google.com/.
2. Register a Web App and copy its web configuration into `firebase.js`.
3. Enable Authentication → Sign-in method → Anonymous.
4. Create a Cloud Firestore database.
5. Publish the included `firestore.rules` rules.
6. Host on HTTPS (GitHub Pages is HTTPS).

The included Firebase integration signs in anonymously and publishes a basic public player profile and leaderboard. The local game simulation, friends list and chat composer work as a browser-local prototype; cross-player friend requests and realtime private chat are **not implemented yet**. Do not treat this starter as a production-ready secure multiplayer backend. For production, validate all economy-changing actions on a trusted server/Cloud Functions, add moderation/report/block tools, rate limits, and stricter Firestore rules.

## Important
- Virtual currency and financial outcomes are fictional game mechanics, not real banking or investment advice.
- Never place Firebase Admin/service-account credentials in frontend files.
- `firestore.rules` are starter rules and need a security review before public launch.
